import 'package:deliveryapp/view/screen/orders/accepted.dart';
import 'package:deliveryapp/view/screen/orders/pending.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

abstract class HomeScreenController extends GetxController {
  changePage(int currentpage);
}

class HomeScreenControllerImp extends HomeScreenController {
  int currentpage = 0;

  List<Widget> listPage = [
    const OrdersPending(),
    const OrdersAccepted(),
  ];

  List bottomappbar = [
    {"title": "Pending", "icon": Icons.pending_actions},
    {"title": "Accepted", "icon": Icons.now_widgets_outlined},
  ];

  @override
  changePage(int i) {
    currentpage = i;
    update();
  }
}

class AppLink {
  //Server
  static const String server =
      "http://192.168.1.75/ticker_cart_app"; //home wifi
  // static const String server =
  //     "http://192.168.137.219/ticker_cart_app"; // salah wifi
  // static const String server =
  //     "http://192.168.75.219/ticker_cart_app"; // mahmoud wifi

  //images
  static const String imagesStatic = "$server/upload";
  static const String imagesCategories = "$imagesStatic/categories";
  static const String imagesItems = "$imagesStatic/items";

  //Auth
  static const String logIn = "$server/delivery/auth/login.php";

  //Orders
  static const String pendingorders = "$server/delivery/orders/pending.php";
  static const String acceptedorders = "$server/delivery/orders/accepted.php";
  static const String approveOrders = "$server/delivery/orders/approve.php";
  static const String archiveorders = "$server/delivery/orders/archive.php";
  static const String detailsorders = "$server/delivery/orders/details.php";
  static const String donedelivery = "$server/delivery/orders/done.php";
}

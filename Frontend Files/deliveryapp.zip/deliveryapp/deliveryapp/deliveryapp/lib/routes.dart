import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:deliveryapp/core/constant/routes.dart';
import 'package:deliveryapp/core/middleware/mymiddleware.dart';
import 'package:deliveryapp/view/screen/auth/login.dart';
import 'package:deliveryapp/view/screen/homescreen.dart';
import 'package:deliveryapp/view/screen/language.dart';
import 'package:deliveryapp/view/screen/orders/archive.dart';
import 'package:deliveryapp/view/screen/orders/details.dart';
import 'package:deliveryapp/view/screen/orders/pending.dart';

List<GetPage<dynamic>>? routes = [
  GetPage(
      name: "/", page: () => const Language(), middlewares: [MyMiddleWare()]),
  GetPage(name: AppRoute.login, page: () => const Login()),
  GetPage(name: AppRoute.orderspending, page: () => const OrdersPending()),
  GetPage(name: AppRoute.ordersarchive, page: () => const OrdersArchiveView()),
  GetPage(name: AppRoute.ordersdetails, page: () => const OrdersDetails()),
  GetPage(name: AppRoute.homepage, page: () => const HomeScreen()),
];

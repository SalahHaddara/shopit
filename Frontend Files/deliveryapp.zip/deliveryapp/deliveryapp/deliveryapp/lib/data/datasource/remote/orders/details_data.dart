import 'package:deliveryapp/core/class/crud.dart';
import 'package:deliveryapp/link_api.dart';

class OrdersDetailsData {
  Crud crud;
  OrdersDetailsData(this.crud);
  getData(String id) async {
    var response = await crud.postData(AppLink.detailsorders, {"id": id});
    return response.fold((l) => l, (r) => r);
  }
}

import 'package:deliveryapp/core/class/crud.dart';
import 'package:deliveryapp/link_api.dart';

class OrdersPendingData {
  Crud crud;
  OrdersPendingData(this.crud);
  getData() async {
    var response = await crud.postData(AppLink.pendingorders, {});
    return response.fold((l) => l, (r) => r);
  }

  approveOrders(String deliveryid, String ordersid) async {
    var response = await crud.postData(AppLink.approveOrders,
        {"deliveryid": deliveryid, "ordersid": ordersid});
    return response.fold((l) => l, (r) => r);
  }
}

import 'package:deliveryapp/core/class/crud.dart';
import 'package:deliveryapp/link_api.dart';

class OrdersAcceptedData {
  Crud crud;
  OrdersAcceptedData(this.crud);
  getData(String deliveryid) async {
    var response =
        await crud.postData(AppLink.acceptedorders, {"id": deliveryid});
    return response.fold((l) => l, (r) => r);
  }

  doneDelivery(String ordersid, String usersid) async {
    var response = await crud.postData(
        AppLink.donedelivery, {"ordersid": ordersid, "usersid": usersid});
    return response.fold((l) => l, (r) => r);
  }
}

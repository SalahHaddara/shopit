import 'dart:io';
import 'package:get/get.dart';
import 'package:deliveryapp/view/widget/auth/custombuttonauth.dart';

Future<bool> alertExitapp() {
  Get.defaultDialog(
    title: "Exit ?",
    middleText: "Do you want to exit the app ?",
    confirm: CustomButtomAuth(text: "Confirm", onPressed: () => exit(0)),
    cancel: CustomButtomAuth(text: "Cancel", onPressed: () => Get.back()),
  );
  return Future.value(true);
}

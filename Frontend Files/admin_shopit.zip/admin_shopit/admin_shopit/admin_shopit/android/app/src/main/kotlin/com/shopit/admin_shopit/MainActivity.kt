package com.shopit.admin_shopit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

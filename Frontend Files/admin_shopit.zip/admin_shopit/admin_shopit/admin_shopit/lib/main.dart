import 'package:admin_shopit/bindings/initialbindings.dart';
import 'package:admin_shopit/core/localization/translation.dart';
import 'package:admin_shopit/core/services/services.dart';
import 'package:admin_shopit/routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'core/localization/changelocal.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initialServices();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    LocaleController controller = Get.put(LocaleController());
    return GetMaterialApp(
      translations: MyTranslation(),
      debugShowCheckedModeBanner: false,
      locale: controller.language,
      theme: controller.apptheme,
      getPages: routes,
      initialBinding: InitialBindings(),
    );
  }
}

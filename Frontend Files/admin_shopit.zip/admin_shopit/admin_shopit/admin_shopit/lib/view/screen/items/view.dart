import 'package:admin_shopit/controller/items/view_controller.dart';
import 'package:admin_shopit/core/class/handlingdataview.dart';
import 'package:admin_shopit/core/constant/color.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:admin_shopit/link_api.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ItemsView extends StatelessWidget {
  const ItemsView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(ItemsController());
    return Scaffold(
      appBar: AppBar(
        title: const Text('Items'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.toNamed(AppRoute.itemsAdd);
        },
        backgroundColor: AppColor.primaryColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.add),
      ),
      body: GetBuilder<ItemsController>(
        builder: (controller) => HandlingDataView(
          statusRequest: controller.statusRequest,
          widget: WillPopScope(
            onWillPop: () {
              return controller.myback();
            },
            child: ListView.builder(
              itemCount: controller.data.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: CachedNetworkImage(
                      imageUrl:
                          "${AppLink.imagesItems}/${controller.data[index].itemsImage}",
                      width: 70),
                  title: Text(controller.data[index].itemsName!),
                  subtitle: Text(controller.data[index].categoriesName!),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Get.defaultDialog(
                            title: "Delete Category",
                            middleText:
                                "Are you sure you want to delete this category?",
                            onCancel: () {},
                            onConfirm: () {
                              controller.deleteItem(
                                controller.data[index].itemsId!,
                                controller.data[index].itemsImage!,
                              );
                              Get.back();
                            },
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(16, 38),
                          backgroundColor: AppColor.primaryColor,
                        ),
                        child: const Icon(Icons.delete_outline),
                      ),
                      const SizedBox(
                        width: 6,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          controller.goToPageEdit(controller.data[index]);
                        },
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(16, 38),
                          backgroundColor: AppColor.primaryColor,
                        ),
                        child: const Icon(Icons.edit_outlined),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:admin_shopit/controller/categories/view_controller.dart';
import 'package:admin_shopit/core/class/handlingdataview.dart';
import 'package:admin_shopit/core/constant/color.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:admin_shopit/link_api.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

class CategoriesView extends StatelessWidget {
  const CategoriesView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CategoriesController());
    return Scaffold(
      appBar: AppBar(
        title: const Text('Categories'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.toNamed(AppRoute.categoriesAdd);
        },
        backgroundColor: AppColor.primaryColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.add),
      ),
      body: GetBuilder<CategoriesController>(
        builder: (controller) => HandlingDataView(
          statusRequest: controller.statusRequest,
          widget: WillPopScope(
            onWillPop: () {
              return controller.myback();
            },
            child: ListView.builder(
              itemCount: controller.data.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: FutureBuilder<String>(
                    future: _loadSvgIcon(
                        "${AppLink.imagesCategories}/${controller.data[index].categoriesImage}"),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const CircularProgressIndicator();
                      } else if (snapshot.hasError) {
                        return const Icon(Icons.error);
                      } else {
                        return SvgPicture.network(
                          snapshot.data!,
                          width: 40,
                          height: 40,
                        );
                      }
                    },
                  ),
                  title: Text(controller.data[index].categoriesName!),
                  subtitle: Text(controller.data[index].categoriesDatetime!),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Get.defaultDialog(
                            title: "Delete Category",
                            middleText:
                                "Are you sure you want to delete this category?",
                            onCancel: () {},
                            onConfirm: () {
                              controller.deleteCategory(
                                controller.data[index].categoriesId!,
                                controller.data[index].categoriesImage!,
                              );
                              Get.back();
                            },
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(16, 38),
                          backgroundColor: AppColor.primaryColor,
                        ),
                        child: const Icon(Icons.delete_outline),
                      ),
                      const SizedBox(
                        width: 6,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          controller.goToPageEdit(controller.data[index]);
                        },
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(16, 38),
                          backgroundColor: AppColor.primaryColor,
                        ),
                        child: const Icon(Icons.edit_outlined),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Future<String> _loadSvgIcon(String imageUrl) async {
    // Assume fetching SVG icon from network
    return imageUrl;
  }
}

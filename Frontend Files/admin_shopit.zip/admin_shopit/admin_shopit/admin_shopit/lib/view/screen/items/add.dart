import 'package:admin_shopit/controller/items/add_controller.dart';
import 'package:admin_shopit/core/class/handlingdataview.dart';
import 'package:admin_shopit/core/constant/color.dart';
import 'package:admin_shopit/core/function/validInput.dart';
import 'package:admin_shopit/core/shared/CustomTextFormGlobal.dart';
import 'package:admin_shopit/core/shared/custombutton.dart';
import 'package:admin_shopit/core/shared/customdropdown.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ItemsAdd extends StatelessWidget {
  const ItemsAdd({super.key});

  @override
  Widget build(BuildContext context) {
    ItemsAddController controller = Get.put(ItemsAddController());
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Item'),
      ),
      body: GetBuilder<ItemsAddController>(
          builder: (controller) => HandlingDataView(
                statusRequest: controller.statusRequest!,
                widget: Container(
                  padding: const EdgeInsets.all(10),
                  child: Form(
                    key: controller.formState,
                    child: ListView(
                      children: [
                        CustomTextFormGlobal(
                            hinttext: "Enter Item's name",
                            labeltext: "item's name",
                            iconData: Icons.drive_file_rename_outline,
                            mycontroller: controller.name,
                            valid: (val) {
                              return validInput(val!, 1, 30, "");
                            },
                            isNumber: false),
                        CustomTextFormGlobal(
                            hinttext: "Enter Item's name in Arabic",
                            labeltext: "item's name in Arabic",
                            iconData: Icons.drive_file_rename_outline,
                            mycontroller: controller.namear,
                            valid: (val) {
                              return validInput(val!, 1, 30, "");
                            },
                            isNumber: false),
                        CustomTextFormGlobal(
                            hinttext: "Enter item's description ",
                            labeltext: "items's description",
                            iconData: Icons.description_outlined,
                            mycontroller: controller.desc,
                            valid: (val) {
                              return validInput(val!, 1, 250, "");
                            },
                            isNumber: false),
                        CustomTextFormGlobal(
                            hinttext: "Enter item's description in arabic ",
                            labeltext: "items's description in arabic",
                            iconData: Icons.description_outlined,
                            mycontroller: controller.descar,
                            valid: (val) {
                              return validInput(val!, 1, 250, "");
                            },
                            isNumber: false),
                        CustomTextFormGlobal(
                            hinttext: "count",
                            labeltext: "count",
                            iconData: Icons.numbers,
                            mycontroller: controller.count,
                            valid: (val) {
                              return validInput(val!, 1, 30, "");
                            },
                            isNumber: true),
                        CustomTextFormGlobal(
                            hinttext: "price",
                            labeltext: "price",
                            iconData: Icons.price_change_outlined,
                            mycontroller: controller.price,
                            valid: (val) {
                              return validInput(val!, 1, 30, "");
                            },
                            isNumber: true),
                        CustomTextFormGlobal(
                            hinttext: "discount",
                            labeltext: "discount",
                            iconData: Icons.percent_outlined,
                            mycontroller: controller.discount,
                            valid: (val) {
                              return validInput(val!, 1, 30, "");
                            },
                            isNumber: true),
                        CustomDropDown(
                          title: "Choose Category",
                          listdata: controller.dropDownList,
                          dropdownSelectedName: controller.catname!,
                          dropdownSelectedId: controller.catid!,
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: MaterialButton(
                            color: AppColor.primaryColor,
                            textColor: Colors.white,
                            onPressed: () {
                              controller.showoptionimage();
                            },
                            child: const Text("Choose item's image"),
                          ),
                        ),
                        if (controller.file != null)
                          Image.file(controller.file!, width: 100, height: 100),
                        CustomButton(
                            text: "Add",
                            onPressed: () {
                              controller.addData();
                            }),
                      ],
                    ),
                  ),
                ),
              )),
    );
  }
}

import 'package:admin_shopit/core/constant/color.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:admin_shopit/controller/home_controller.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(HomeControllerImp());

    return Scaffold(
      appBar: AppBar(
        title: const Text("Home"),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              buildButton(
                text: "Categories",
                svgPath: "assets/svgs/category.svg",
                color: AppColor.primaryColor,
                onPressed: () {
                  Get.toNamed(AppRoute.categoriesView);
                },
              ),
              const SizedBox(height: 20),
              buildButton(
                text: "Items",
                svgPath: "assets/svgs/product.svg",
                color: AppColor.primaryColor,
                onPressed: () {
                  Get.toNamed(AppRoute.itemsView);
                },
              ),
              const SizedBox(height: 20),
              buildButton(
                text: "Orders",
                svgPath: "assets/svgs/order.svg",
                color: AppColor.primaryColor,
                onPressed: () {
                  Get.toNamed(AppRoute.ordersHome);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildButton({
    required String text,
    required String svgPath,
    required Color color,
    required void Function()? onPressed,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        backgroundColor: color,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: SvgPicture.asset(
              svgPath,
              width: 40,
              height: 40,
              colorFilter:
                  const ColorFilter.mode(Colors.white, BlendMode.srcIn),
            ),
          ),
          Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}

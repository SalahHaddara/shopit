import 'package:admin_shopit/view/screen/categories/add.dart';
import 'package:admin_shopit/view/screen/categories/edit.dart';
import 'package:admin_shopit/view/screen/categories/view.dart';
import 'package:admin_shopit/view/screen/home.dart';
import 'package:admin_shopit/view/screen/items/add.dart';
import 'package:admin_shopit/view/screen/items/edit.dart';
import 'package:admin_shopit/view/screen/items/view.dart';
import 'package:admin_shopit/view/screen/language.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:admin_shopit/core/middleware/mymiddleware.dart';
import 'package:admin_shopit/view/screen/auth/login.dart';
import 'package:admin_shopit/view/screen/orders/archive.dart';
import 'package:admin_shopit/view/screen/orders/details.dart';
import 'package:admin_shopit/view/screen/orders/pending.dart';

import 'view/screen/orders/screens.dart';

List<GetPage<dynamic>>? routes = [
  GetPage(name: "/", page: () => Language(), middlewares: [MyMiddleWare()]),
  GetPage(name: AppRoute.login, page: () => const Login()),
  GetPage(name: AppRoute.orderspending, page: () => const OrdersPending()),
  GetPage(name: AppRoute.ordersarchive, page: () => const OrdersArchiveView()),
  GetPage(name: AppRoute.ordersdetails, page: () => const OrdersDetails()),
  GetPage(name: AppRoute.homepage, page: () => const HomePage()),

  //Categories
  GetPage(name: AppRoute.homepage, page: () => const HomePage()),
  GetPage(name: AppRoute.categoriesView, page: () => const CategoriesView()),
  GetPage(name: AppRoute.categoriesAdd, page: () => const CategoriesAdd()),
  GetPage(name: AppRoute.categoriesEdit, page: () => const CategoriesEdit()),

  //Items
  GetPage(name: AppRoute.homepage, page: () => const HomePage()),
  GetPage(name: AppRoute.itemsView, page: () => const ItemsView()),
  GetPage(name: AppRoute.itemsAdd, page: () => const ItemsAdd()),
  GetPage(name: AppRoute.itemsEdit, page: () => const ItemsEdit()),

  //Orders
  GetPage(name: AppRoute.ordersHome, page: () => const OrderScreen()),
];

import 'package:get/get.dart';

class MyTranslation extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        "ar": {
          "1": "اختر اللغة",
        },
        "en": {
          "1": "Choose Language",
          "2": "number two",
          "3": "number three",
          "4": "number four",
          "5": "number five",
        }
      };
}

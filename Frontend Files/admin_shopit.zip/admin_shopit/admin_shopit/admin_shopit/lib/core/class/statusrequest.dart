enum StatusRequest {
  none,
  loading,
  success,
  failure,
  serverfailure,
  offlinefailure,
  serverException,
}

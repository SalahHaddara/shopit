import 'dart:io';
import 'package:admin_shopit/controller/categories/view_controller.dart';
import 'package:admin_shopit/core/class/statusrequest.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:admin_shopit/core/function/handlingdatacontroller.dart';
import 'package:admin_shopit/core/function/uploadfile.dart';
import 'package:admin_shopit/core/services/services.dart';
import 'package:admin_shopit/data/datasource/remote/categories_data.dart';
import 'package:admin_shopit/data/model/categoriesmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class CategoriesEditController extends GetxController {
  CategoriesData categoriesData = CategoriesData(Get.find());
  List<CategoriesModel> data = [];
  CategoriesModel? categoriesModel;
  StatusRequest? statusRequest = StatusRequest.none;
  late TextEditingController name;
  late TextEditingController namear;
  GlobalKey<FormState> formState = GlobalKey<FormState>();

  chooseImage() async {
    file = await fileUploadGallery(true);
    update();
  }

  MyServices myServices = Get.find();

  File? file;

  editData() async {
    if (formState.currentState!.validate()) {
      statusRequest = StatusRequest.loading;
      update();
      Map data = {
        "id": categoriesModel!.categoriesId!,
        "name": name.text,
        "namear": namear.text,
        "imageold": categoriesModel!.categoriesImage!
      };
      var response = await categoriesData.edit(data, file);
      print("=============================== Controller $response ");
      statusRequest = handlingData(response);
      if (StatusRequest.success == statusRequest) {
        // Start backend
        if (response['status'] == "success") {
          Get.offNamed(AppRoute.categoriesView);
          CategoriesController c = Get.find();
          c.getData();
        } else {
          statusRequest = StatusRequest.failure;
        }
        // End
      }
      update();
    }
  }

  @override
  void onInit() {
    categoriesModel = Get.arguments['categoriesModel'];
    name = TextEditingController();
    namear = TextEditingController();
    name.text = categoriesModel!.categoriesName!;
    namear.text = categoriesModel!.categoriesNameAr!;
    super.onInit();
  }
}

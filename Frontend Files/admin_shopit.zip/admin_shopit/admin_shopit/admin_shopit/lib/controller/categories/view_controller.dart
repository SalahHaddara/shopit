import 'package:admin_shopit/core/class/statusrequest.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:admin_shopit/core/function/handlingdatacontroller.dart';
import 'package:admin_shopit/data/datasource/remote/categories_data.dart';
import 'package:admin_shopit/data/model/categoriesmodel.dart';
import 'package:admin_shopit/data/model/ordersmodel.dart';
import 'package:get/get.dart';

class CategoriesController extends GetxController {
  CategoriesData categoriesData = CategoriesData(Get.find());
  List<CategoriesModel> data = [];
  late StatusRequest statusRequest;
  late OrdersModel ordersModel;

  getData() async {
    data.clear();
    statusRequest = StatusRequest.loading;
    update();
    var response = await categoriesData.get();
    print("=============================== Controller $response ");
    statusRequest = handlingData(response);
    if (StatusRequest.success == statusRequest) {
      // Start backend
      if (response['status'] == "success") {
        List listdata = response['data'];
        data.addAll(listdata.map((e) => CategoriesModel.fromJson(e)));
      } else {
        statusRequest = StatusRequest.failure;
      }
      // End
    }
    update();
  }

  myback() {
    Get.offAllNamed(AppRoute.homepage);
    return Future.value(false);
  }

  deleteCategory(String id, String imagename) {
    categoriesData.delete({"id": id, "imagename": imagename});
    data.removeWhere((element) => element.categoriesId == id);
    update();
  }

  goToPageEdit(CategoriesModel categoriesModel) {
    Get.toNamed(AppRoute.categoriesEdit,
        arguments: {"categoriesModel": categoriesModel});
  }

  @override
  void onInit() {
    getData();
    super.onInit();
  }
}

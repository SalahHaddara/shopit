import 'dart:io';
import 'package:admin_shopit/controller/categories/view_controller.dart';
import 'package:admin_shopit/core/class/statusrequest.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:admin_shopit/core/function/handlingdatacontroller.dart';
import 'package:admin_shopit/core/function/uploadfile.dart';
import 'package:admin_shopit/data/datasource/remote/categories_data.dart';
import 'package:admin_shopit/data/model/categoriesmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class CategoriesAddController extends GetxController {
  CategoriesData categoriesData = CategoriesData(Get.find());

  List<CategoriesModel> data = [];

  StatusRequest? statusRequest = StatusRequest.none;

  late TextEditingController name;
  late TextEditingController namear;

  GlobalKey<FormState> formState = GlobalKey<FormState>();

  chooseImage() async {
    file = await fileUploadGallery(true);
    update();
  }

  @override
  void onInit() {
    name = TextEditingController();
    namear = TextEditingController();

    super.onInit();
  }

  File? file;

  addData() async {
    if (formState.currentState!.validate()) {
      if (file == null) {
        Get.snackbar("No Image", "Please Choose an Image SVG");
      }
      statusRequest = StatusRequest.loading;
      update();
      Map data = {
        "name": name.text,
        "namear": namear.text,
      };
      var response = await categoriesData.add(data, file!);
      print("=============================== Controller $response ");
      statusRequest = handlingData(response);
      if (StatusRequest.success == statusRequest) {
        // Start backend
        if (response['status'] == "success") {
          Get.offNamed(AppRoute.categoriesView);
          CategoriesController c = Get.find();
          c.getData();
        } else {
          statusRequest = StatusRequest.failure;
        }
        // End
      }
      update();
    }
  }
}

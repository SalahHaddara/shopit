import 'package:admin_shopit/view/screen/orders/accepted.dart';
import 'package:admin_shopit/view/screen/orders/archive.dart';
import 'package:admin_shopit/view/screen/orders/pending.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

abstract class OrderScreenController extends GetxController {
  changePage(int currentpage);
}

class OrderScreenControllerImp extends OrderScreenController {
  int currentpage = 0;

  List<Widget> listPage = [
    const OrdersPending(),
    const OrdersAccepted(),
    const OrdersArchiveView()
  ];

  List bottomappbar = [
    {"title": "Pending", "icon": Icons.pending_actions},
    {"title": "Accepted", "icon": Icons.now_widgets_outlined},
    {"title": "Archive  ", "icon": Icons.archive_outlined},
  ];

  @override
  changePage(int i) {
    currentpage = i;
    update();
  }
}

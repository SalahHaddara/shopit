import 'package:admin_shopit/core/class/statusrequest.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:admin_shopit/core/function/handlingdatacontroller.dart';
import 'package:admin_shopit/data/datasource/remote/Items_data.dart';
import 'package:admin_shopit/data/model/Itemsmodel.dart';
import 'package:admin_shopit/data/model/ordersmodel.dart';
import 'package:get/get.dart';

class ItemsController extends GetxController {
  ItemsData itemsData = ItemsData(Get.find());
  List<ItemsModel> data = [];
  late StatusRequest statusRequest;
  late OrdersModel ordersModel;

  getData() async {
    data.clear();
    statusRequest = StatusRequest.loading;
    update();
    var response = await itemsData.get();
    print("=============================== Controller $response ");
    statusRequest = handlingData(response);
    if (StatusRequest.success == statusRequest) {
      // Start backend
      if (response['status'] == "success") {
        List listdata = response['data'];
        data.addAll(listdata.map((e) => ItemsModel.fromJson(e)));
      } else {
        statusRequest = StatusRequest.failure;
      }
      // End
    }
    update();
  }

  myback() {
    Get.offAllNamed(AppRoute.homepage);
    return Future.value(false);
  }

  deleteItem(String id, String imagename) {
    itemsData.delete({"id": id, "imagename": imagename});
    data.removeWhere((element) => element.itemsId == id);
    update();
  }

  goToPageEdit(ItemsModel itemsModel) {
    Get.toNamed(AppRoute.itemsEdit, arguments: {"itemsModel": itemsModel});
  }

  @override
  void onInit() {
    getData();
    super.onInit();
  }
}

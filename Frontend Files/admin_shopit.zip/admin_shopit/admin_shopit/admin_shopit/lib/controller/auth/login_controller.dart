import 'package:admin_shopit/core/class/statusrequest.dart';
import 'package:admin_shopit/core/constant/routes.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:admin_shopit/core/function/handlingdatacontroller.dart';
import 'package:admin_shopit/core/services/services.dart';
import 'package:admin_shopit/data/datasource/remote/auth/login.dart';

abstract class LoginController extends GetxController {
  login();

  goToSignUp();

  goToForgetPassword();
}

class LoginControllerImp extends LoginController {
  LoginData loginData = LoginData(Get.find());
  StatusRequest statusRequest = StatusRequest.none;

  late TextEditingController email;
  late TextEditingController password;
  GlobalKey<FormState> formstate = GlobalKey<FormState>();
  bool isShowPassword = true;
  MyServices myServices = Get.find();

  @override
  login() async {
    if (formstate.currentState!.validate()) {
      statusRequest = StatusRequest.loading;
      update();
      var response = await loginData.postdata(email.text, password.text);
      print("=============================== Controller $response ");
      statusRequest = handlingData(response);
      if (StatusRequest.success == statusRequest) {
        if (response['status'] == "success") {
          //data.addAll(response['data']);

          myServices.sharedPreferences
              .setString("id", response['data']['admin_id'].toString());
          myServices.sharedPreferences
              .setString("username", response['data']['admin_name']);
          myServices.sharedPreferences
              .setString("email", response['data']['admin_email']);
          myServices.sharedPreferences
              .setString("phone", response['data']['admin_phone'].toString());
          myServices.sharedPreferences.setString("step", "2");
          Get.offNamed(AppRoute.homepage);
        } else {
          Get.defaultDialog(
              title: "Login Failed",
              middleText:
                  "Invalid email or password. Please check your credentials and try again.");
          statusRequest = StatusRequest.failure;
        }
      }
      update();
    } else {}
  }

  showPassword() {
    isShowPassword = isShowPassword ? false : true;
    update();
  }

  @override
  goToSignUp() {
    Get.offNamed(AppRoute.signUp);
  }

  @override
  void onInit() {
    email = TextEditingController();
    password = TextEditingController();
    super.onInit();
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  goToForgetPassword() {
    Get.toNamed(AppRoute.forgetPassword);
  }
}

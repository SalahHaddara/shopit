import 'package:get/get.dart';

class HomeControllerImp extends GetxController {}

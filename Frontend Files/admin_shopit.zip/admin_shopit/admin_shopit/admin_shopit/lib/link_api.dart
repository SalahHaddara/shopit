class AppLink {
  //Server
  static const String server =
      "http://192.168.1.75/ticker_cart_app"; //home wifi
  // static const String server =
  //     "http://192.168.66.219/ticker_cart_app"; // salah wifi
  // static const String server =
  //     "http://192.168.75.219/ticker_cart_app"; // mahmoud wifi

  //images
  static const String imagesStatic = "$server/upload";
  static const String imagesCategories = "$imagesStatic/categories";
  static const String imagesItems = "$imagesStatic/items";

  //Auth
  static const String logIn = "$server/admin/auth/login.php";

  //Orders
  static const String approveOrders = "$server/admin/orders/approve.php";
  static const String prepareorders = "$server/admin/orders/prepare.php";

  static const String archiveorders = "$server/admin/orders/archive.php";
  static const String viewpendingorders =
      "$server/admin/orders/viewpending.php";
  static const String viewacceptedorders =
      "$server/admin/orders/viewaccepted.php";
  static const String detailsorders = "$server/admin/orders/details.php";

  // Categories
  static const String categoriesView = "$server/admin/categories/view.php";
  static const String categoriesAdd = "$server/admin/categories/add.php";
  static const String categoriesEdit = "$server/admin/categories/edit.php";
  static const String categoriesDelete = "$server/admin/categories/delete.php";

  // Items
  static const String itemsView = "$server/admin/items/view.php";
  static const String itemsAdd = "$server/admin/items/add.php";
  static const String itemsEdit = "$server/admin/items/edit.php";
  static const String itemsDelete = "$server/admin/items/delete.php";
}

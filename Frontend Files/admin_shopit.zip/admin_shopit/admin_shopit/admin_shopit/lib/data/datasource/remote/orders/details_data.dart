import 'package:admin_shopit/core/class/crud.dart';
import 'package:admin_shopit/link_api.dart';

class OrdersDetailsData {
  Crud crud;
  OrdersDetailsData(this.crud);
  getData(String id) async {
    var response = await crud.postData(AppLink.detailsorders, {"id": id});
    return response.fold((l) => l, (r) => r);
  }
}

import 'package:admin_shopit/core/class/crud.dart';
import 'package:admin_shopit/link_api.dart';

class OrdersArchiveData {
  Crud crud;
  OrdersArchiveData(this.crud);
  getData() async {
    var response = await crud.postData(AppLink.archiveorders, {});
    return response.fold((l) => l, (r) => r);
  }
}

import 'package:admin_shopit/core/class/crud.dart';
import 'package:admin_shopit/link_api.dart';

class OrdersPendingData {
  Crud crud;
  OrdersPendingData(this.crud);
  getData() async {
    var response = await crud.postData(AppLink.viewpendingorders, {});
    return response.fold((l) => l, (r) => r);
  }

  approveOrders(String userid, String ordersid) async {
    var response = await crud.postData(
        AppLink.approveOrders, {"usersid": userid, "ordersid": ordersid});
    return response.fold((l) => l, (r) => r);
  }
}

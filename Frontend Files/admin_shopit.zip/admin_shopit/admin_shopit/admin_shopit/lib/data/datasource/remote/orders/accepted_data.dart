import 'package:admin_shopit/core/class/crud.dart';
import 'package:admin_shopit/link_api.dart';

class OrdersAcceptedData {
  Crud crud;
  OrdersAcceptedData(this.crud);
  getData() async {
    var response = await crud.postData(AppLink.viewacceptedorders, {});
    return response.fold((l) => l, (r) => r);
  }

  prepared(String ordersid, String usersid, String orderstype) async {
    var response = await crud.postData(AppLink.prepareorders,
        {"ordersid": ordersid, "usersid": usersid, "ordertype": orderstype});
    return response.fold((l) => l, (r) => r);
  }
}

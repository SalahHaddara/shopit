import 'package:ticker_cart_app/core/class/crud.dart';
import 'package:ticker_cart_app/link_api.dart';

class CheckoutData {
  Crud crud;
  CheckoutData(this.crud);
  checkout(Map data) async {
    var response = await crud.postData(AppLink.checkout, data);
    return response.fold((l) => l, (r) => r);
  }
}

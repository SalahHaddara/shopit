import 'package:get/get_utils/src/extensions/internacionalization.dart';
import 'package:ticker_cart_app/core/constant/imageasset.dart';
import 'package:ticker_cart_app/data/model/onboardingmodel.dart';

List<OnBoardingModel> onBoardingList = [
  OnBoardingModel(title: "2".tr, body: "3".tr, image: AppImageAsset.img1),
  OnBoardingModel(title: "4".tr, body: "5".tr, image: AppImageAsset.img2),
  OnBoardingModel(title: "6".tr, body: "7".tr, image: AppImageAsset.img3),
];

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/core/function/translatefatabase.dart';
import '../../../controller/home_controller.dart';
import '../../../core/constant/color.dart';
import '../../../data/model/itemsmodel.dart';
import '../../../link_api.dart';

class ListItemsHome extends GetView<HomeControllerImp> {
  const ListItemsHome({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 320,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: (controller.items.length / 2).ceil(),
        itemBuilder: (context, index) {
          return Row(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: SizedBox(
                  width: MediaQuery.of(context).size.width / 2 - 30,
                  child: Center(
                    child: ItemsHome(
                      itemsModel:
                          ItemsModel.fromJson(controller.items[index * 2]),
                    ),
                  ),
                ),
              ),
              if (index * 2 + 1 < controller.items.length)
                const SizedBox(width: 20),
              if (index * 2 + 1 < controller.items.length)
                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width / 2 - 30,
                    child: Center(
                      child: ItemsHome(
                        itemsModel: ItemsModel.fromJson(
                            controller.items[index * 2 + 1]),
                      ),
                    ),
                  ),
                ),
              const SizedBox(width: 20), // Add spacing at the end
            ],
          );
        },
      ),
    );
  }
}

class ItemsHome extends GetView<HomeControllerImp> {
  final ItemsModel itemsModel;

  const ItemsHome({Key? key, required this.itemsModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        controller.goToPageProductDetails(itemsModel);
      },
      child: SizedBox(
        width: MediaQuery.of(context).size.width / 2 - 30,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(15)),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: Image.network(
                  "${AppLink.imagesItems}/${itemsModel.itemsImage}",
                  height: 100,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            // Constrained height for content
            SizedBox(
              height: 80, // Adjust height based on your content size
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${translateDatabase(itemsModel.itemsNameAr, itemsModel.itemsName)}",
                      style: const TextStyle(
                        color: AppColor.grey2,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      "${(double.parse(itemsModel.itemsPriceDiscount!)).toStringAsFixed(2)} \$",
                      style: const TextStyle(
                        color: AppColor.primaryColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

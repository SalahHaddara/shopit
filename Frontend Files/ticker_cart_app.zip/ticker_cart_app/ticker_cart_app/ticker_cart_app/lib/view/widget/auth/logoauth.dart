import 'package:ticker_cart_app/core/constant/imageasset.dart';
import 'package:flutter/material.dart';

class LogoAuth extends StatelessWidget {
  const LogoAuth({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 140, // Increase the width to accommodate padding
      height: 140, // Increase the height to accommodate padding
      child: CircleAvatar(
        backgroundColor: Colors.teal,
        child: Padding(
          padding: const EdgeInsets.all(16.0), // Add padding

          child: Image.asset(
            AppImageAsset.logo,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}

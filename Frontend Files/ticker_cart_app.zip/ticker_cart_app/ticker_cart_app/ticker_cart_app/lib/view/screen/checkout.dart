import 'package:ticker_cart_app/controller/checkout_controller.dart';
import 'package:ticker_cart_app/core/class/handlingdataview.dart';
import 'package:ticker_cart_app/core/constant/color.dart';
import 'package:ticker_cart_app/core/constant/imageasset.dart';
import 'package:ticker_cart_app/view/widget/checkout/carddeliveerytype.dart';
import 'package:ticker_cart_app/view/widget/checkout/cardpaymentmethod.dart';
import 'package:ticker_cart_app/view/widget/checkout/cardshippingaddress.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Checkout extends StatelessWidget {
  const Checkout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    CheckoutController controller = Get.put(CheckoutController());
    return Scaffold(
      appBar: AppBar(
        title: Text('checkout'.tr),
      ),
      bottomNavigationBar: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: MaterialButton(
            color: AppColor.secondColor,
            textColor: Colors.white,
            onPressed: () {
              controller.checkout();
            },
            child: Text('checkout'.tr,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          )),
      body: GetBuilder<CheckoutController>(
          builder: (controller) => HandlingDataView(
              statusRequest: controller.statusRequest,
              widget: Container(
                  padding: const EdgeInsets.all(20),
                  child: ListView(
                    children: [
                      Text(
                        'choosePaymentMethod'.tr,
                        style: const TextStyle(
                            color: AppColor.secondColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 16),
                      ),
                      const SizedBox(height: 10),
                      InkWell(
                        onTap: () {
                          controller.choosePaymentMethod("0");
                        },
                        child: CardPaymentMethodCheckout(
                            title: 'cashOnDelivery'.tr,
                            isActive: controller.paymentMethod == "0"),
                      ),
                      const SizedBox(height: 10),
                      InkWell(
                        onTap: () {
                          controller.choosePaymentMethod("1");
                        },
                        child: CardPaymentMethodCheckout(
                            title: 'paymentCards'.tr,
                            isActive: controller.paymentMethod == "1"),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'chooseDeliveryType'.tr,
                        style: const TextStyle(
                            color: AppColor.secondColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 16),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          InkWell(
                            onTap: () {
                              controller.chooseDeliveryType("0");
                            },
                            child: CardDeliveryTypeCheckout(
                                imagename: AppImageAsset.delivery,
                                title: 'delivery'.tr,
                                active: controller.deliveryType == "0"),
                          ),
                          const SizedBox(width: 10),
                          InkWell(
                            onTap: () {
                              controller.chooseDeliveryType("1");
                            },
                            child: CardDeliveryTypeCheckout(
                                imagename: AppImageAsset.pickup,
                                title: 'receive'.tr,
                                active: controller.deliveryType == "1"),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      if (controller.deliveryType == "0")
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'shippingAddress'.tr,
                              style: const TextStyle(
                                  color: AppColor.secondColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16),
                            ),
                            const SizedBox(height: 10),
                            ...List.generate(
                              controller.dataaddress.length,
                              (index) => InkWell(
                                onTap: () {
                                  controller.chooseShippingAddress(
                                      controller.dataaddress[index].addressId!);
                                },
                                child: CardShppingAddressCheckout(
                                    title:
                                        "${controller.dataaddress[index].addressName}",
                                    body:
                                        "${controller.dataaddress[index].addressCity} ${controller.dataaddress[index].addressStreet}",
                                    isactive: controller.addressid ==
                                        controller
                                            .dataaddress[index].addressId),
                              ),
                            )
                          ],
                        )
                    ],
                  )))),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/core/constant/routes.dart';
import '../../controller/settings_controller.dart';
import '../../core/constant/color.dart';
import 'package:url_launcher/url_launcher.dart';

class Settings extends StatelessWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SettingsController controller = Get.put(SettingsController());
    return SafeArea(
      child: ListView(
        children: [
          Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                Container(height: Get.width / 3, color: AppColor.primaryColor),
                Positioned(
                    top: Get.width / 3.9,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                          color: const Color(0xFFFFFFFF),
                          borderRadius: BorderRadius.circular(100)),
                      child: const Icon(
                        size: 100,
                        Icons.person_outline,
                      ),
                    )),
              ]),
          const SizedBox(height: 100),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Card(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(
                  onTap: () {
                    Get.toNamed(AppRoute.ordersarchive);
                  },
                  trailing: const Icon(Icons.archive_outlined),
                  title: Text('settings_page_archive'.tr),
                ),
                ListTile(
                  onTap: () {
                    Get.toNamed(AppRoute.addressView);
                  },
                  trailing: const Icon(Icons.location_on_outlined),
                  title: Text('settings_page_address'.tr),
                ),
                ListTile(
                  onTap: () {},
                  trailing: const Icon(Icons.help_outline_rounded),
                  title: Text('settings_page_about_us'.tr),
                ),
                ListTile(
                  onTap: () => launchUrl(Uri.parse('tel:123456789')),
                  trailing: const Icon(Icons.phone_callback_outlined),
                  title: Text('settings_page_contact_us'.tr),
                ),
                ListTile(
                  onTap: () {
                    controller.logout();
                  },
                  title: Text('settings_page_logout'.tr),
                  trailing: const Icon(Icons.exit_to_app),
                ),
              ]),
            ),
          )
        ],
      ),
    );
  }
}

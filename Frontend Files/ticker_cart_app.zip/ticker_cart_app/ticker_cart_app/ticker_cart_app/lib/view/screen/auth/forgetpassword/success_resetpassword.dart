import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/controller/auth/successresetpassword_controller.dart';
import 'package:ticker_cart_app/core/constant/color.dart';
import 'package:ticker_cart_app/view/widget/auth/custombuttonauth.dart';
import 'package:ticker_cart_app/view/widget/auth/customtextbodyauth.dart';
import 'package:ticker_cart_app/view/widget/auth/customtexttitleauth.dart';

class SuccessResetPassword extends StatelessWidget {
  const SuccessResetPassword({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SuccessResetPasswordControllerImp controller =
        Get.put(SuccessResetPasswordControllerImp());
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: AppColor.backgroundcolor,
        elevation: 0.0,
        title: Text('Success',
            style: Theme.of(context)
                .textTheme
                .headline1!
                .copyWith(color: AppColor.grey)),
      ),
      body: Container(
        padding: const EdgeInsets.all(15),
        child: Column(
          children: [
            const Center(
              child: Icon(
                Icons.check_circle_outline,
                size: 200,
                color: AppColor.primaryColor,
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            const CustomTextTitleAuth(text: "Password Successfully Reset"),
            const SizedBox(height: 30),
            const CustomTextBodyAuth(
                text:
                    "Congratulations! Your password has been successfully reset. You can now log in using your new credentials. If you have any further questions or concerns, feel free to reach out to our support team for assistance."),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: CustomButtomAuth(
                  text: "Go To Login",
                  onPressed: () {
                    controller.goToPageLogin();
                  }),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

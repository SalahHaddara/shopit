import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/controller/favorite_controller.dart';
import 'package:ticker_cart_app/controller/offerscontroller.dart';
import 'package:ticker_cart_app/core/class/handlingdataview.dart';
import 'package:ticker_cart_app/core/constant/routes.dart';
import 'package:ticker_cart_app/view/screen/home.dart';
import 'package:ticker_cart_app/view/widget/customappbar.dart';
import 'package:ticker_cart_app/view/widget/offers/customsitemsoffer.dart';

class OffersView extends StatelessWidget {
  const OffersView({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(OfferController());
    Get.put(FavoriteController());

    return GetBuilder<OfferController>(
      builder: (controller) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: ListView(
          children: [
            CustomAppBar(
              titleappbar: 'findProduct'.tr,
              onPressedSearch: () {
                controller.onSeachItems();
              },
              onPressedIconFavorite: () {
                Get.toNamed(AppRoute.myfavroite);
              },
              mycontroller: controller.search!,
              onChanged: (val) {
                controller.checkSearch(val);
              },
            ),
            controller.isSearch
                ? ListItemsSearch(listdatamodel: controller.listdata)
                : HandlingDataView(
                    statusRequest: controller.statusRequest,
                    widget: ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: controller.data.length,
                      itemBuilder: (context, index) => CustomListItemsOffer(
                        itemsModel: controller.data[index],
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

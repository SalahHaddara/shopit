import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/controller/auth/successsignup_controller.dart';
import 'package:ticker_cart_app/core/constant/color.dart';
import 'package:ticker_cart_app/view/widget/auth/custombuttonauth.dart';
import 'package:ticker_cart_app/view/widget/auth/customtextbodyauth.dart';
import 'package:ticker_cart_app/view/widget/auth/customtexttitleauth.dart';

class SuccessSignUp extends StatelessWidget {
  const SuccessSignUp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SuccessSignUpControllerImp controller =
        Get.put(SuccessSignUpControllerImp());
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: AppColor.backgroundcolor,
        elevation: 0.0,
        title: Text('Success',
            style: Theme.of(context)
                .textTheme
                .headline1!
                .copyWith(color: AppColor.grey)),
      ),
      body: Container(
        padding: const EdgeInsets.all(15),
        child: Column(
          children: [
            const Center(
              child: Icon(
                Icons.check_circle_outline,
                size: 200,
                color: AppColor.primaryColor,
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            const CustomTextTitleAuth(text: "Your Email is Checked "),
            const SizedBox(height: 30),
            const CustomTextBodyAuth(
                text:
                    "Your email has been verified, and your account has been successfully created. Welcome to Ticker Cart! You're now ready to log in and explore all the fantastic products and deals we have to offer. Happy shopping!"),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: CustomButtomAuth(
                  text: "Go To Login",
                  onPressed: () {
                    controller.goToPageLogin();
                  }),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

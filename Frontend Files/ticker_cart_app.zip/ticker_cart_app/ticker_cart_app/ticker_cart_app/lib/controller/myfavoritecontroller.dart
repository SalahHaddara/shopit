import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/controller/home_controller.dart';
import 'package:ticker_cart_app/core/class/statusrequest.dart';
import 'package:ticker_cart_app/core/function/handlingdatacontroller.dart';
import 'package:ticker_cart_app/core/services/services.dart';
import 'package:ticker_cart_app/data/datasource/remote/myfavorite_data.dart';
import 'package:ticker_cart_app/data/model/myfavorite.dart';

class MyFavoriteController extends SearchMixController {
  MyFavoriteData favoriteData = MyFavoriteData(Get.find());

  List<MyFavoriteModel> data = [];

  MyServices myServices = Get.find();

//  key => id items
//  Value => 1 OR 0

  getData() async {
    data.clear();
    statusRequest = StatusRequest.loading;
    var response = await favoriteData
        .getData(myServices.sharedPreferences.getString("id")!);
    print("=============================== Controller $response ");
    statusRequest = handlingData(response);
    if (StatusRequest.success == statusRequest) {
      // Start backend
      if (response['status'] == "success") {
        List responsedata = response['data'];
        data.addAll(responsedata.map((e) => MyFavoriteModel.fromJson(e)));
        print("data");
        print(data);
      } else {
        statusRequest = StatusRequest.failure;
      }
      // End
    }
    update();
  }

  deleteFromFavorite(String favroitedid) {
    // data.clear();
    // statusRequest = StatusRequest.loading;
    favoriteData.deleteData(favroitedid);
    data.removeWhere((element) => element.favoriteId == favroitedid);
    update();
  }

  @override
  void onInit() {
    search = TextEditingController();
    getData();
    super.onInit();
  }
}

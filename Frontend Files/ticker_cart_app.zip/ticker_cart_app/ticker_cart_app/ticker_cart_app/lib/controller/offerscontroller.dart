import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/controller/home_controller.dart';
import 'package:ticker_cart_app/core/class/statusrequest.dart';
import 'package:ticker_cart_app/core/function/handlingdatacontroller.dart';
import 'package:ticker_cart_app/data/datasource/remote/offersdata.dart';
import 'package:ticker_cart_app/data/model/itemsmodel.dart';

class OfferController extends SearchMixController {
  OfferData offerData = OfferData(Get.find());
  List<ItemsModel> data = [];
  late StatusRequest statusRequest;

  getData() async {
    statusRequest = StatusRequest.loading;
    var response = await offerData.getData();
    print("=============================== Controller $response ");
    statusRequest = handlingData(response);
    if (StatusRequest.success == statusRequest) {
      // Start backend
      if (response['status'] == "success") {
        List listdata2 = response['data'];
        data.addAll(listdata2.map((e) => ItemsModel.fromJson(e)));
      } else {
        statusRequest = StatusRequest.failure;
      }
      // End
    }
    update();
  }

  @override
  void onInit() {
    search = TextEditingController();
    getData();
    super.onInit();
  }
}

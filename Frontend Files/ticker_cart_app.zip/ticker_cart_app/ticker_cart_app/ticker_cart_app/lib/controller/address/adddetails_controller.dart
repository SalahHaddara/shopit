import 'package:ticker_cart_app/core/class/statusrequest.dart';
import 'package:ticker_cart_app/core/constant/routes.dart';
import 'package:ticker_cart_app/core/function/handlingdatacontroller.dart';
import 'package:ticker_cart_app/core/services/services.dart';
import 'package:ticker_cart_app/data/datasource/remote/address_data.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class AddAddressDetailsController extends GetxController {
  StatusRequest statusRequest = StatusRequest.none;

  AddressData addressData = AddressData(Get.find());

  MyServices myServices = Get.find();

  TextEditingController? name;
  TextEditingController? city;
  TextEditingController? street;

  String lat = "54";
  String long = "54";

  intialData() {
    name = TextEditingController();
    city = TextEditingController();
    street = TextEditingController();
    // _getLocation();
    print(lat);
    print(long);
  }

  // Future<void> _getLocation() async {
  //   try {
  //     Position position = await Geolocator.getCurrentPosition(
  //         desiredAccuracy: LocationAccuracy.bestForNavigation);
  //
  //     // Update lat and long directly
  //     lat = position.latitude.toString();
  //     long = position.longitude.toString();
  //   } on PlatformException catch (e) {
  //     print(
  //         "Error: $e"); // Handle platform-specific errors (e.g., GPS disabled)
  //   } on PermissionDeniedException {
  //     print("Permissions denied. Please grant location permissions.");
  //   } catch (e) {
  //     print("Error: $e"); // Handle other exceptions
  //   }
  // }

  addAddress() async {
    statusRequest = StatusRequest.loading;
    update();

    var response = await addressData.addData(
        myServices.sharedPreferences.getString("id")!,
        name!.text,
        city!.text,
        street!.text,
        lat,
        long);

    print("=============================== Controller $response ");

    statusRequest = handlingData(response);

    if (StatusRequest.success == statusRequest) {
      // Start backend
      if (response['status'] == "success") {
        Get.offAllNamed(AppRoute.homepage);
      } else {
        statusRequest = StatusRequest.failure;
      }
      // End
    }
    update();
  }

  @override
  void onInit() {
    intialData();
    super.onInit();
  }
}

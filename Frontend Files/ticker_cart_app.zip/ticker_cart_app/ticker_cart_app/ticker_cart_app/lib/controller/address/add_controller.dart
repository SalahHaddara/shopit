import 'package:get/get.dart';
import 'package:ticker_cart_app/core/class/statusrequest.dart';

class AddAddressController extends GetxController {
  // Completer<GoogleMapController>? completercontroller;
  // Position? position;
  StatusRequest statusRequest = StatusRequest.loading;
  // CameraPosition? kGooglePlex;
  //
  // getCurrentLocation() async {
  //   Position position = await Geolocator.getCurrentPosition();
  //   kGooglePlex = CameraPosition(
  //     target: LatLng(position!.latitude, position!.longitude),
  //     zoom: 14.4746,
  //   );
  //   statusRequest = StatusRequest.none;
  //   update();
  // }

  @override
  void onInit() {
    // getCurrentLocation();
    // completercontroller = Completer<GoogleMapController>();
    super.onInit();
  }
}

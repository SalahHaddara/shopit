import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ticker_cart_app/view/screen/offers.dart';
import 'package:ticker_cart_app/view/screen/orders/pending.dart';
import 'package:ticker_cart_app/view/screen/settings.dart';
import '../view/screen/home.dart';

abstract class HomeScreenController extends GetxController {
  changePage(int currentpage);
}

class HomeScreenControllerImp extends HomeScreenController {
  int currentpage = 0;

  List<Widget> listPage = [
    const HomePage(),
    const OffersView(),
    const OrdersPending(),
    const Settings()
  ];

  List bottomappbar = [
    {"title": "home".tr, "icon": Icons.home_outlined},
    {"title": "offers".tr, "icon": Icons.discount_outlined},
    {"title": "orders".tr, "icon": Icons.pending_actions},
    {"title": "profile".tr, "icon": Icons.person_outline_rounded},
  ];

  @override
  changePage(int i) {
    currentpage = i;
    update();
  }
}

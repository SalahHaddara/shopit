import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:ticker_cart_app/core/constant/routes.dart';
import 'package:ticker_cart_app/core/middleware/mymiddleware.dart';
import 'package:ticker_cart_app/view/screen/offers.dart';
import 'package:ticker_cart_app/view/screen/address/adddetails.dart';
import 'package:ticker_cart_app/view/screen/address/view.dart';
import 'package:ticker_cart_app/view/screen/auth/forgetpassword/forgetpassword.dart';
import 'package:ticker_cart_app/view/screen/auth/login.dart';
import 'package:ticker_cart_app/view/screen/auth/forgetpassword/resetpassword.dart';
import 'package:ticker_cart_app/view/screen/auth/signup.dart';
import 'package:ticker_cart_app/view/screen/auth/forgetpassword/success_resetpassword.dart';
import 'package:ticker_cart_app/view/screen/auth/success_signup.dart';
import 'package:ticker_cart_app/view/screen/auth/forgetpassword/verifycode.dart';
import 'package:ticker_cart_app/view/screen/auth/verifycodesignup.dart';
import 'package:ticker_cart_app/view/screen/cart.dart';
import 'package:ticker_cart_app/view/screen/checkout.dart';
import 'package:ticker_cart_app/view/screen/homescreen.dart';
import 'package:ticker_cart_app/view/screen/items.dart';
import 'package:ticker_cart_app/view/screen/language.dart';
import 'package:ticker_cart_app/view/screen/myfavorite.dart';
import 'package:ticker_cart_app/view/screen/onboarding.dart';
import 'package:ticker_cart_app/view/screen/orders/archive.dart';
import 'package:ticker_cart_app/view/screen/orders/details.dart';
import 'package:ticker_cart_app/view/screen/orders/pending.dart';
import 'package:ticker_cart_app/view/screen/productdetails.dart';
import 'package:ticker_cart_app/view/screen/settings.dart';

List<GetPage<dynamic>>? routes = [
  //Auth
  GetPage(
      name: "/", page: () => const Language(), middlewares: [MyMiddleWare()]),
  GetPage(name: AppRoute.login, page: () => const Login()),
  GetPage(name: AppRoute.signUp, page: () => const SignUp()),
  GetPage(name: AppRoute.forgetPassword, page: () => const ForgetPassword()),
  GetPage(name: AppRoute.verfiyCode, page: () => const VerfiyCode()),
  GetPage(name: AppRoute.resetPassword, page: () => const ResetPassword()),
  GetPage(
      name: AppRoute.successResetpassword,
      page: () => const SuccessResetPassword()),
  GetPage(name: AppRoute.successSignUp, page: () => const SuccessSignUp()),
  GetPage(
      name: AppRoute.verifyCodeSignUp, page: () => const VerfiyCodeSignUp()),
  //OnBoarding
  GetPage(name: AppRoute.onBoarding, page: () => const OnBoarding()),
  //Home
  GetPage(name: AppRoute.homepage, page: () => const HomeScreen()),
  GetPage(name: AppRoute.items, page: () => const Items()),
  GetPage(name: AppRoute.productdetails, page: () => const ProductDetails()),
  GetPage(name: AppRoute.myfavroite, page: () => const MyFavorite()),

  GetPage(name: AppRoute.settings, page: () => const Settings()),
  GetPage(name: AppRoute.cart, page: () => const Cart()),
  GetPage(name: AppRoute.offers, page: () => const OffersView()),

  //Address
  GetPage(name: AppRoute.addressView, page: () => const AddressView()),
  GetPage(
      name: AppRoute.addressAdddetails, page: () => const AddressAddDetails()),

  //Checkout
  GetPage(name: AppRoute.checkout, page: () => const Checkout()),
  GetPage(name: AppRoute.orderspending, page: () => const OrdersPending()),
  GetPage(name: AppRoute.ordersarchive, page: () => const OrdersArchiveView()),
  GetPage(name: AppRoute.ordersdetails, page: () => const OrdersDetails()),
];

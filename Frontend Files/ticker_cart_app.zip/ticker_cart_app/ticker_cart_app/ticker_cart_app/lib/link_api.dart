class AppLink {
  //Server
  // static const String server =
  //     "http://192.168.1.75/ticker_cart_app"; //home wifi
  static const String server =
      "http://192.168.137.219/ticker_cart_app"; // salah wifi
  // static const String server =
  //     "http://192.168.75.219/ticker_cart_app"; // mahmoud wifi
  // static const String server =
  //     "http://192.168.132.219/ticker_cart_app"; // majed wifi

  //images
  static const String imagesStatic = "$server/upload";
  static const String imagesCategories = "$imagesStatic/categories";
  static const String imagesItems = "$imagesStatic/items";

  //Auth
  static const String signUp = "$server/auth/signup.php";
  static const String verifyCodeSignUp = "$server/auth/verifycode.php";
  static const String resend = "$server/auth/resend.php";
  static const String logIn = "$server/auth/login.php";

  //ForgetPassword
  static const String checkEmail = "$server/forgetpassword/checkemail.php";
  static const String verifyCodeForgetPassword =
      "$server/forgetpassword/verifycode.php";
  static const String resetPassword =
      "$server/forgetpassword/resetpassword.php";

  //Home
  static const String homePage = "$server/home.php";

  //Items
  static const String items = "$server/items/items.php";
  static const String search = "$server/items/search.php";
  static const String offers = "$server/offers.php";

  // Favorite
  static const String favoriteAdd = "$server/favorite/add.php";
  static const String favoriteRemove = "$server/favorite/remove.php";
  static const String favoriteView = "$server/favorite/view.php";
  static const String deletefromfavroite =
      "$server/favorite/deletefromfavroite.php";

  //cart
  static const String cartAdd = "$server/cart/add.php";
  static const String cartDelete = "$server/cart/delete.php";
  static const String cartGetcountitems = "$server/cart/getcountitems.php";
  static const String cartView = "$server/cart/view.php";
  static const String checkCoupon = "$server/coupon/checkcoupon.php";

  //Address
  static const String addressAdd = "$server/address/add.php";
  static const String addressEdit = "$server/address/edit.php";
  static const String addressView = "$server/address/view.php";
  static const String addressDelete = "$server/address/delete.php";

  //Checkout
  static const String checkout = "$server/orders/checkout.php";
  static const String pendingorders = "$server/orders/pending.php";
  static const String ordersarchive = "$server/orders/archive.php";
  static const String ordersdetails = "$server/orders/details.php";
  static const String ordersdelete = "$server/orders/delete.php";
}

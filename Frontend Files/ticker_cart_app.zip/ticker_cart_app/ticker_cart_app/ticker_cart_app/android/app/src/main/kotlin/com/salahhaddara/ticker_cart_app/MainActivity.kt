package com.salahhaddara.ticker_cart_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

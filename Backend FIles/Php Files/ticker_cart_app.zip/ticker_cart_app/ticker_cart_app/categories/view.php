<?php 

include "../connect.php" ; 

getAllData("categories")  ;


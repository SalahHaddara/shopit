<?php

include "../../connect.php" ; 

getAllData("items1view") ; 